<?php
namespace AppBundle\Entity;
class filter{
	
private $age;
private $jobtype;

private $active;
public function setAge($age){$this->age=$age;}
public function getAge(){return $this->age;}

public function setJobtype($jobtype){$this->jobtype=$jobtype;}
public function getJobtype(){return $this->jobtype;}
public function setActive($active){$this->active=$active;}
public function getActive(){return $this->active;}
}