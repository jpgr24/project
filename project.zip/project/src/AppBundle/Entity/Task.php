<?php

// src/AppBundle/Entity/Task.php
namespace AppBundle\Entity;

class Task
{
    protected $name;
    protected $optionage;

    protected $work;
    protected $optionwork;
    protected $sortby;
    protected $age;

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    

    public function setSortby($sortby){
    	$this->sortby=$sortby;
    }
    public function getSortby(){
    	return $this->sortby;
    }

    public function getAge()
    {
        return $this->age;
    }

    public function setAge($age=null)
    {
        $this->age = $age;
    }
    public function getWork()
    {
        return $this->work;
    }

    public function setWork($work=null)
    {
        $this->work = $work;
    }
    public function setOptionage($optionage){$this->optionage=$optionage;}
    public function getOptionage(){return $this->optionage;}
    public function setOptionwork($optionwork){$this->optionwork=$optionwork;}
    public function getOptionwork(){return $this->optionwork;}
}