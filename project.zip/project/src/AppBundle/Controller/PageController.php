<?php
// src/AppBundle/Controller/LuckyController.php
namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use AppBundle\Entity\user;
use AppBundle\Entity\Task;




class PageController extends Controller
{

    /**
     * @Route("/")
     */
    public function mainAction(Request $request)
    {
  
$task = new Task();
        $task->setName('Write name');
        

        $form = $this->createFormBuilder($task)
            ->add('name', TextType::class)
            ->add('save', SubmitType::class, ['label' => 'Find'])
            ->getForm();
            
            $form->handleRequest($request);
            $f=$form->createView();
            $s=$f;
            $t=$task->getName();
            $names=str_getcsv($t," ");

            $task2=new Task();
            $task2->setName($task->getName());

            $task2->setAge('age');
            $s=$task2->getAge();
            $newform = $this->createFormBuilder($task2)
            ->add('name', TextType::class)->add('sortby', ChoiceType::class, [
    'choices'  => [
        'Name' => 'name',
        'Lastname' => 'lastname',
        'Age' => 'age',
        'Jobtitle' => 'jobtitle'
    ],
])->add('optionage', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])->add('optionwork', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])
            ->add('save', SubmitType::class, ['label' => 'Find'])
            ->getForm();
            
            $newform->handleRequest($request);
            $nf=$newform->createView();


            $formage = $this->createFormBuilder($task2)
            ->add('name', TextType::class)->add('sortby', ChoiceType::class, [
    'choices'  => [
        'Name' => 'name',
        'Lastname' => 'lastname',
        'Age' => 'age',
        'Jobtitle' => 'jobtitle'
    ],
])->add('age', TextType::class)->add('optionage', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])->add('optionwork', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])
            ->add('save', SubmitType::class, ['label' => 'Find'])
            ->getForm();
            
            $formage->handleRequest($request);
            $fa=$formage->createView();

            $formwork = $this->createFormBuilder($task2)
            ->add('name', TextType::class)->add('sortby', ChoiceType::class, [
    'choices'  => [
        'Name' => 'name',
        'Lastname' => 'lastname',
        'Age' => 'age',
        'Jobtitle' => 'jobtitle'
    ],
])->add('work', TextType::class)->add('optionage', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])->add('optionwork', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])
            ->add('save', SubmitType::class, ['label' => 'Find'])
            ->getForm();
            
            $formwork->handleRequest($request);
            $fw=$formwork->createView();

            $formall = $this->createFormBuilder($task2)
            ->add('name', TextType::class)->add('sortby', ChoiceType::class, [
    'choices'  => [
        'Name' => 'name',
        'Lastname' => 'lastname',
        'Age' => 'age',
        'Jobtitle' => 'jobtitle'
    ],
])->add('age', TextType::class)->add('work', TextType::class)->add('optionage', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])->add('optionwork', ChoiceType::class, [
    'choices'  => [
        'No' => 'no',
        'Yes' => 'yes',
        
    ],
])
            ->add('save', SubmitType::class, ['label' => 'Find'])
            ->getForm();
            
            $formall->handleRequest($request);
            $fll=$formall->createView();
        
        $sortBy='l';

        $filterage=0;
        
          if ($newform->isSubmitted() && $newform->isValid()) {
      
        $task2 = $newform->getData();
$s=$task2->getAge();

        $repository = $this->getDoctrine()->getRepository(user::class);
        $user='';
        $user2='';
        $user4='';
     
       $sortBy=$task2->getSortby();

       
     
     
        if (($sortBy=='age')||($sortBy=='jobtitle')){
          $user=$repository->findBy(['name'=>$task2->getName()],[$sortBy=>'ASC'] );
          $user2=$repository->findBy(['lastname'=>$task2->getName()],[$sortBy=>'ASC']);
        }
          else{$user=$repository->findBy(['name'=>$task2->getName()],['lastname'=>'ASC']);
          $user2=$repository->findBy(['lastname'=>$task2->getName()],['name'=>'ASC']);
        }
       
          
        
        
        $user3=$task2->getName();
        $names=str_getcsv($user3," ");
        if(count($names)>1)
        if($sortBy=='jobtitle')
        $user3 = $repository->findBy(['name' => $names[0] ,'lastname' => $names[1]],['jobtitle'=>'ASC']);else $user3 = $repository->findBy(['name' => $names[0],'lastname' => $names[1]],['age'=>'ASC']

        

    
);
        if($task2->getOptionwork()!='yes')
        if($task2->getOptionage()!='yes'){
        //$us=$user[0];
        return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$nf, 's'=>$s] );}else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fa, 's'=>$s] );}else if($task2->getOptionage()!='yes')

        { return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fw, 's'=>$s] ); }else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fll, 's'=>$s] );}
} 

if ($formage->isSubmitted() && $formage->isValid()) {
      
        $task2 = $formage->getData();
$s=$task2->getAge();

        $repository = $this->getDoctrine()->getRepository(user::class);
        $user='';
        $user2='';
        $user4='';
     
       $sortBy=$task2->getSortby();

       
     
     
        if ($sortBy=='jobtitle'){
          $user=$repository->findBy(['name'=>$task2->getName(),'age'=>$task2->getAge()],[$sortBy=>'ASC'] );
          $user2=$repository->findBy(['lastname'=>$task2->getName(),'age'=>$task2->geAge()],[$sortBy=>'ASC']);
        }
          else{$user=$repository->findBy(['name'=>$task2->getName(),'age'=>$task2->getAge()],['lastname'=>'ASC']);
          $user2=$repository->findBy(['lastname'=>$task2->getName(),'age'=>$task2->getAge()],['name'=>'ASC']);
        }
       
          
        
        
        $user3=$task2->getName();
        $names=str_getcsv($user3," ");
        if(count($names)>1)
        if($sortBy=='jobtitle')
        $user3 = $repository->findBy(['name' => $names[0] ,'lastname' => $names[1]],['jobtitle'=>'ASC']);else $user3 = $repository->findBy(['name' => $names[0],'lastname' => $names[1]],['age'=>'ASC']

        

    
);
        if($task2->getOptionwork()!='yes')
        if($task2->getOptionage()!='yes'){
        //$us=$user[0];
        return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$nf, 's'=>$s] );}else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fa, 's'=>$s] );}else if($task2->getOptionage()!='yes')

        { return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fw, 's'=>$s] ); }else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fll, 's'=>$s] );}
} 
   if ($formwork->isSubmitted() && $formwork->isValid()) {
      
        $task2 = $formwork->getData();
$s=$task2->getAge();

        $repository = $this->getDoctrine()->getRepository(user::class);
        $user='';
        $user2='';
        $user4='';
     
       $sortBy=$task2->getSortby();

       
     
     
        if ($sortBy=='age'){
          $user=$repository->findBy(['name'=>$task2->getName(),'jobtitle'=>$task2->getWork()],[$sortBy=>'ASC'] );
          $user2=$repository->findBy(['lastname'=>$task2->getName(),'jobtitle'=>$task2->getWork()],[$sortBy=>'ASC']);
        }
          else{$user=$repository->findBy(['name'=>$task2->getName(),'jobtitle'=>$task2->getWork()],['lastname'=>'ASC']);
          $user2=$repository->findBy(['lastname'=>$task2->getName(),'jobtitle'=>$task2->getWork()],['name'=>'ASC']);
        }
       
          
        
        
        $user3=$task2->getName();
        $names=str_getcsv($user3," ");
        if(count($names)>1)
        if($sortBy=='jobtitle')
        $user3 = $repository->findBy(['name' => $names[0] ,'lastname' => $names[1]],['jobtitle'=>'ASC']);else $user3 = $repository->findBy(['name' => $names[0],'lastname' => $names[1]],['age'=>'ASC']

        

    
);
        if($task2->getOptionwork()!='yes')
        if($task2->getOptionage()!='yes'){
        //$us=$user[0];
        return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$nf, 's'=>$s] );}else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fa, 's'=>$s] );}else if($task2->getOptionage()!='yes')

        { return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fw, 's'=>$s] ); }else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fll, 's'=>$s] );}
} 

if ($formall->isSubmitted() && $formall->isValid()) {
      
        $task2 = $formall->getData();
$s=$task2->getAge();

        $repository = $this->getDoctrine()->getRepository(user::class);
        $user='';
        $user2='';
        $user4='';
     
       

       
     $user=$repository->findBy(['name'=>$task2->getName(),'age'=>$task2->getAge(),'jobtitle'=>$task2->getWork()],['lastname'=>'ASC']);
          $user2=$repository->findBy(['lastname'=>$task2->getName(),'age'=>$task2->getAge(),'jobtitle'=>$task2->getWork()],['name'=>'ASC']);
     
       
       
          
        
        
        $user3=$task2->getName();
        $names=str_getcsv($user3," ");
        if(count($names)>1)
        if($sortBy=='jobtitle')
        $user3 = $repository->findBy(['name' => $names[0] ,'lastname' => $names[1]],['jobtitle'=>'ASC']);else $user3 = $repository->findBy(['name' => $names[0],'lastname' => $names[1]],['age'=>'ASC']

        

    
);
        if($task2->getOptionwork()!='yes')
        if($task2->getOptionage()!='yes'){
        //$us=$user[0];
        return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$nf, 's'=>$s] );}else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fa, 's'=>$s] );}else if($task2->getOptionage()!='yes')

        { return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fw, 's'=>$s] ); }else{return $this->render('find.html.twig', ['user'=>$user, 'user2'=>$user2, 'user3'=>$user3, 'newform'=>$fll, 's'=>$s] );}
} 

      return $this->render('template.html.twig', ['form' => $f]);
    }
 
    
}


